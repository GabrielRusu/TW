create PACKAGE BODY functii IS
--------------------------------------------------------------------------------

PROCEDURE STATISTICS(p_copac OUT VARCHAR2) IS
    v_totalmale NUMBER;
    v_totalfemale NUMBER;
    v_procmale NUMBER;
    v_procfemale NUMBER;
    v_rezultat VARCHAR2(10000) := '';
    
    CURSOR lista  IS
       SELECT districts.dis_id,districts.name,damages.fem_death,damages.male_death FROM districts
       join damages on (damages.dis_id = districts.dis_id);

BEGIN
    FOR i IN lista LOOP 
    v_totalmale := 0;
    v_totalfemale := 0;
     select sum(fem_pop) into v_totalfemale from population
     where i.dis_id = dis_id;
     select sum(male_pop) into v_totalmale from population
     where i.dis_id = dis_id;
     
     v_procmale := round(i.male_death*100/v_totalmale,5);
     v_procfemale :=round(i.fem_death*100/v_totalfemale,5);
     
     if(v_procmale < v_procfemale) then 
      v_rezultat := v_rezultat||'\n'||'In districtul '||i.name||' procentual , numarul de decese de sex feminin este mai mare decat cel masculin(femei:'||v_procfemale||'% barbati:'||v_procmale||'%)';
  
      else
      v_rezultat := v_rezultat||'\n'||'In districtul '||i.name||' procentual , numarul de decese de sex masculin este mai mare decat cel feminin(femei:'||v_procfemale||'% barbati:'||v_procmale||'%)';
    end if;
    END LOOP;  
    
    p_copac := v_rezultat;
END;

---------------------------------------------------------------------------------
FUNCTION ceva RETURN NUMBER AS
	v_female_dead NUMBER;
	v_male_dead NUMBER;
	v_male_total NUMBER;
	v_female_total NUMBER;
	v_male_alive NUMBER;
	v_female_alive NUMBER;
  dis NUMBER := 15;
  cevaa NUMBER;
BEGIN
	SELECT male_death, fem_death INTO v_male_dead, v_female_dead FROM damages WHERE dis_id = 15;
	SELECT male_pop, fem_pop INTO v_male_total, v_female_total FROM population WHERE dis_id = 15;
	v_male_alive := v_male_total - v_male_dead;
	v_female_alive := v_female_total -v_female_dead;
  cevaa := v_male_alive + v_female_alive;
  
  return cevaa;
END;
---------------------------------------------------------------------------------
function copaci return varchar2
AS
v_max NUMBER := 0;
v_name VARCHAR2(50);
CURSOR lista  IS
       SELECT * FROM districts
	join damages on(districts.dis_id = damages.dis_id);
BEGIN
	FOR i IN LISTA LOOP     
        if(i.public_damaged > v_max ) then v_max := i.public_damaged;
					v_name := i.name;
          END IF;
    END LOOP; 	
return v_name;
END;


END functii;