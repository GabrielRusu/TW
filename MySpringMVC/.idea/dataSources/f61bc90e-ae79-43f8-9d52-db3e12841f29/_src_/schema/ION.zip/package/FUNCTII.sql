create PACKAGE functii IS
  PROCEDURE STATISTICS(p_copac OUT VARCHAR2);
  function ceva return number;
  function copaci return varchar2;
  
END functii;