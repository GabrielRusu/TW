create PROCEDURE STATISTICS(p_copac OUT VARCHAR2) IS
    v_totalmale NUMBER;
    v_totalfemale NUMBER;
    v_procmale NUMBER;
    v_procfemale NUMBER;
    v_rezultat VARCHAR2(10000) := '';
    
    CURSOR lista  IS
       SELECT districts.dis_id,districts.name,damages.fem_death,damages.male_death FROM districts
       join damages on (damages.dis_id = districts.dis_id);

BEGIN
    FOR i IN lista LOOP 
    v_totalmale := 0;
    v_totalfemale := 0;
     select sum(fem_pop) into v_totalfemale from population
     where i.dis_id = dis_id;
     select sum(male_pop) into v_totalmale from population
     where i.dis_id = dis_id;
     
     v_procmale := round(i.male_death*100/v_totalmale,5);
     v_procfemale :=round(i.fem_death*100/v_totalfemale,5);
     
     if(v_procmale < v_procfemale) then 
      v_rezultat := v_rezultat||'<'||'In districtul '||i.name||' au murit mai multe femei (femei: '||v_procfemale||'% barbati: '||v_procmale||'%)';
      else
      v_rezultat := v_rezultat||'<'||'In districtul '||i.name||' au murit mai multi barbati (femei: '||v_procfemale||'% barbati: '||v_procmale||'%)';
    end if;
    END LOOP;  
    
    p_copac := v_rezultat;
END;