create PROCEDURE inViata(dis IN NUMBER, p_people OUT VARCHAR2) AS
	v_female_dead NUMBER;
	v_male_dead NUMBER;
	v_male_total NUMBER;
	v_female_total NUMBER;
	v_male_alive NUMBER;
	v_female_alive NUMBER;
BEGIN
	SELECT male_death, fem_death INTO v_male_dead, v_female_dead FROM damages WHERE dis_id = dis;
	SELECT male_pop, fem_pop INTO v_male_total, v_female_total FROM population WHERE dis_id = dis;
	v_male_alive := v_male_total - v_male_dead;
	v_female_alive := v_female_total -v_female_dead;
  
  
  p_people := 'Au ramas in viata '||v_male_alive||' barbati si '||v_female_alive||' femei';
  
END;