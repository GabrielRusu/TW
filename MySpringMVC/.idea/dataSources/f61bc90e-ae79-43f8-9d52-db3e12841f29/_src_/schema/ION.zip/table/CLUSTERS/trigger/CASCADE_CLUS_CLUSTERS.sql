create trigger CASCADE_CLUS_CLUSTERS
	after delete
	on CLUSTERS
	for each row
BEGIN
  DELETE FROM projects
  WHERE projects.clus_id = :OLD.clus_id;
	DELETE FROM organisations
  WHERE organisations.cluster = :OLD.clus_id;
END;