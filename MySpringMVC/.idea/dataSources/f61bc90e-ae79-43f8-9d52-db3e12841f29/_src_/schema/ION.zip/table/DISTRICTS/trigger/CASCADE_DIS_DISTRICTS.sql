create trigger CASCADE_DIS_DISTRICTS
	after delete
	on DISTRICTS
	for each row
BEGIN
  DELETE FROM damages
  WHERE damages.dis_id = :OLD.dis_id;
	DELETE FROM projects
  WHERE projects.dis_id = :OLD.dis_id;
	DELETE FROM municipalities
  WHERE municipalities.dis_id = :OLD.dis_id;
	DELETE FROM earthquakes
  WHERE earthquakes.dis_id = :OLD.dis_id;
	DELETE FROM population
  WHERE population.dis_id = :OLD.dis_id;
	DELETE FROM villages
  WHERE villages.dis_id = :OLD.dis_id;
	DELETE FROM survey
  WHERE survey.dist_id = :OLD.dis_id;
END;