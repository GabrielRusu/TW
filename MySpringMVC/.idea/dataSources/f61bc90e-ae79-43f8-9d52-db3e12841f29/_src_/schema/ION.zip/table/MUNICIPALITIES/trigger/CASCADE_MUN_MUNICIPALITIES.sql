create trigger CASCADE_MUN_MUNICIPALITIES
	after delete
	on MUNICIPALITIES
	for each row
BEGIN
	DELETE FROM projects
  WHERE projects.mun_id = :OLD.mun_id;
	DELETE FROM earthquakes
  WHERE earthquakes.mun_id = :OLD.mun_id;
	DELETE FROM population
  WHERE population.mun_id = :OLD.mun_id;
	DELETE FROM villages
  WHERE villages.mun_id = :OLD.mun_id;
END;